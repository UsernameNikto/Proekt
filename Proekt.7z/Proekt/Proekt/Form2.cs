﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proekt
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a, b;
            a = comboBox1.Text;
            b = comboBox2.Text;
            if (a == "")
                textBox4.Text = String.Format("");
            else if (a == "Березники")
                if (b == "00:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(500);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(300);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "03:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(525);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(325);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "06:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(550);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(350);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "09:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(575);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(375);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "12:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(600);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(400);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "15:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(625);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(425);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "18:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(650);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(450);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "21:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(675);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(475);
                    else
                        textBox4.Text = String.Format("");
                else
                    textBox4.Text = String.Format("");
            else if (a == "Кунгур")
                if (b == "00:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(300);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(100);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "03:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(325);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(125);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "06:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(350);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(150);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "09:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(375);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(175);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "12:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(400);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(200);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "15:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(425);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(225);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "18:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(450);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(250);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "21:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(475);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(275);
                    else
                        textBox4.Text = String.Format("");
                else
                    textBox4.Text = String.Format("");
            else if (a == "Оса")
                if (b == "00:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(400);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(200);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "03:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(425);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(225);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "06:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(450);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(250);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "09:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(475);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(275);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "12:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(500);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(300);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "15:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(525);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(325);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "18:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(550);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(350);
                    else
                        textBox4.Text = String.Format("");
                else if (b == "21:00")
                    if (radioButton1.Checked == true)
                        textBox4.Text = Convert.ToString(575);
                    else if (radioButton2.Checked == true)
                        textBox4.Text = Convert.ToString(375);
                    else
                        textBox4.Text = String.Format("");
                else
                    textBox4.Text = String.Format("");
            ;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string c, d, f, g, h, i, j, k, l, m, stroka;
            c = textBox1.Text;
            d = textBox2.Text;
            f = textBox3.Text;
            g = textBox4.Text;
            h = textBox5.Text;
            i = textBox6.Text;
            j = textBox6.Text;
            k = textBox7.Text;
            l = comboBox1.Text;
            m = comboBox2.Text;
            if (c != "" && d != "" && f != "" && g != "" && h != "" && i != "" && j != "" && k != "")
            {
                stroka = k + " " + l + " " + m + " " + g + " руб." + Environment.NewLine;
                System.IO.File.AppendAllText(@"C:\Users\pl9097\source\repos\Proekt\Text.txt", stroka);
                MessageBox.Show("Операция прошла успешно.");
            }
            else
            {
                MessageBox.Show("Введите данные.");
            }
            ;
        }
    }
}
